
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "C:/Users/win11/Desktop/projects/game-tools-develop/maniac/deps/imgui/backends/imgui_impl_dx9.cpp" "CMakeFiles/maniac.dir/deps/imgui/backends/imgui_impl_dx9.cpp.obj" "gcc" "CMakeFiles/maniac.dir/deps/imgui/backends/imgui_impl_dx9.cpp.obj.d"
  "C:/Users/win11/Desktop/projects/game-tools-develop/maniac/deps/imgui/backends/imgui_impl_win32.cpp" "CMakeFiles/maniac.dir/deps/imgui/backends/imgui_impl_win32.cpp.obj" "gcc" "CMakeFiles/maniac.dir/deps/imgui/backends/imgui_impl_win32.cpp.obj.d"
  "C:/Users/win11/Desktop/projects/game-tools-develop/maniac/deps/imgui/imgui.cpp" "CMakeFiles/maniac.dir/deps/imgui/imgui.cpp.obj" "gcc" "CMakeFiles/maniac.dir/deps/imgui/imgui.cpp.obj.d"
  "C:/Users/win11/Desktop/projects/game-tools-develop/maniac/deps/imgui/imgui_draw.cpp" "CMakeFiles/maniac.dir/deps/imgui/imgui_draw.cpp.obj" "gcc" "CMakeFiles/maniac.dir/deps/imgui/imgui_draw.cpp.obj.d"
  "C:/Users/win11/Desktop/projects/game-tools-develop/maniac/deps/imgui/imgui_tables.cpp" "CMakeFiles/maniac.dir/deps/imgui/imgui_tables.cpp.obj" "gcc" "CMakeFiles/maniac.dir/deps/imgui/imgui_tables.cpp.obj.d"
  "C:/Users/win11/Desktop/projects/game-tools-develop/maniac/deps/imgui/imgui_widgets.cpp" "CMakeFiles/maniac.dir/deps/imgui/imgui_widgets.cpp.obj" "gcc" "CMakeFiles/maniac.dir/deps/imgui/imgui_widgets.cpp.obj.d"
  "C:/Users/win11/Desktop/projects/game-tools-develop/maniac/main.cpp" "CMakeFiles/maniac.dir/main.cpp.obj" "gcc" "CMakeFiles/maniac.dir/main.cpp.obj.d"
  "C:/Users/win11/Desktop/projects/game-tools-develop/maniac/maniac.cpp" "CMakeFiles/maniac.dir/maniac.cpp.obj" "gcc" "CMakeFiles/maniac.dir/maniac.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
