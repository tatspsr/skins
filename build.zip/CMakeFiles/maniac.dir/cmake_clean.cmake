file(REMOVE_RECURSE
  "CMakeFiles/maniac.dir/deps/imgui/backends/imgui_impl_dx9.cpp.obj"
  "CMakeFiles/maniac.dir/deps/imgui/backends/imgui_impl_dx9.cpp.obj.d"
  "CMakeFiles/maniac.dir/deps/imgui/backends/imgui_impl_win32.cpp.obj"
  "CMakeFiles/maniac.dir/deps/imgui/backends/imgui_impl_win32.cpp.obj.d"
  "CMakeFiles/maniac.dir/deps/imgui/imgui.cpp.obj"
  "CMakeFiles/maniac.dir/deps/imgui/imgui.cpp.obj.d"
  "CMakeFiles/maniac.dir/deps/imgui/imgui_draw.cpp.obj"
  "CMakeFiles/maniac.dir/deps/imgui/imgui_draw.cpp.obj.d"
  "CMakeFiles/maniac.dir/deps/imgui/imgui_tables.cpp.obj"
  "CMakeFiles/maniac.dir/deps/imgui/imgui_tables.cpp.obj.d"
  "CMakeFiles/maniac.dir/deps/imgui/imgui_widgets.cpp.obj"
  "CMakeFiles/maniac.dir/deps/imgui/imgui_widgets.cpp.obj.d"
  "CMakeFiles/maniac.dir/main.cpp.obj"
  "CMakeFiles/maniac.dir/main.cpp.obj.d"
  "CMakeFiles/maniac.dir/maniac.cpp.obj"
  "CMakeFiles/maniac.dir/maniac.cpp.obj.d"
  "libmaniac.dll.a"
  "maniac.exe"
  "maniac.exe.manifest"
  "maniac.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/maniac.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
