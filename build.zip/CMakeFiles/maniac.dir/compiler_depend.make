# Empty compiler generated dependencies file for maniac.
# This may be replaced when dependencies are built.
